# Wii Channel Renderer Bundle

Source: Unknown
Title ID: HAFE
- Banner: 608x456, 17 frames @ 60fps
- Icon: 170x96, 499 frames @ 60fps
- Audio: included (audio.wav)

## Usage

This bundle contains all the parsed data needed to render a Wii channel
banner/icon animation using the WeWAD BannerRenderer.

### Setup

1. Install the renderer package and GSAP:
   ```
   npm install @firstform/wii-channel-renderer gsap
   ```

2. Load the bundle and create a renderer:

   ```js
   import { BannerRenderer } from "@firstform/wii-channel-renderer";
   import { loadRendererBundle } from "@firstform/wii-channel-renderer/bundle-loader";

   // Load the bundle ZIP
   const response = await fetch("/assets/my-bundle.zip");
   const bundle = await loadRendererBundle(await response.arrayBuffer());

   // Create a canvas and renderer for the banner
   const canvas = document.getElementById("banner-canvas");
   canvas.width = bundle.manifest.banner.width;
   canvas.height = bundle.manifest.banner.height;

   const { layout, startAnim, loopAnim, tplImages, fonts } = bundle.banner;
   const renderer = new BannerRenderer(canvas, layout, startAnim ?? loopAnim, tplImages, {
     startAnim,
     loopAnim,
     fonts,
     displayAspect: 16 / 9, // or 4/3
     ...bundle.manifest.rendererOptions,
     renderState: bundle.manifest.banner.animSelection.renderState,
     playbackMode: bundle.manifest.banner.animSelection.playbackMode,
   });

   // Start playback (uses GSAP internally if available)
   renderer.play();
   ```

### React Component Example

```jsx
import { useRef, useEffect } from "react";
import { BannerRenderer } from "@firstform/wii-channel-renderer";
import { loadRendererBundle } from "@firstform/wii-channel-renderer/bundle-loader";

function WiiBanner({ bundleUrl, aspectRatio = 4 / 3 }) {
  const canvasRef = useRef(null);
  const rendererRef = useRef(null);

  useEffect(() => {
    let cancelled = false;

    (async () => {
      const res = await fetch(bundleUrl);
      const bundle = await loadRendererBundle(await res.arrayBuffer());
      if (cancelled) return;

      const { layout, startAnim, loopAnim, tplImages, fonts } = bundle.banner;
      const canvas = canvasRef.current;
      canvas.width = bundle.manifest.banner.width;
      canvas.height = bundle.manifest.banner.height;

      rendererRef.current = new BannerRenderer(
        canvas, layout, startAnim ?? loopAnim, tplImages, {
          startAnim, loopAnim, fonts,
          displayAspect: aspectRatio,
          ...bundle.manifest.rendererOptions,
          renderState: bundle.manifest.banner.animSelection.renderState,
          playbackMode: bundle.manifest.banner.animSelection.playbackMode,
        },
      );
      rendererRef.current.play();
    })();

    return () => {
      cancelled = true;
      rendererRef.current?.dispose();
    };
  }, [bundleUrl, aspectRatio]);

  return <canvas ref={canvasRef} style={{ width: "100%", height: "auto" }} />;
}
```

### Audio

If `audio.wav` is present in the bundle, the manifest includes loop metadata:

```js
if (bundle.audioWav) {
  const blob = new Blob([bundle.audioWav], { type: "audio/wav" });
  const audioEl = new Audio(URL.createObjectURL(blob));

  const { loopFlag, loopStart, sampleRate, durationSeconds } = bundle.manifest.audio;
  const loopStartTime = loopFlag ? loopStart / sampleRate : 0;

  // When audio ends (or reaches end), seek back to loop point
  audioEl.addEventListener("ended", () => {
    audioEl.currentTime = loopStartTime;
    audioEl.play().catch(() => {});
  });
  audioEl.addEventListener("timeupdate", () => {
    if (audioEl.currentTime >= durationSeconds - 0.05) {
      audioEl.currentTime = loopStartTime;
    }
  });

  audioEl.play().catch(() => {});
}
```

## Bundle Contents

- `manifest.json` — Metadata (dimensions, frame counts, fps, renderer options)
- `banner/layout.json` — Parsed BRLYT layout
- `banner/anim-start.json` — Start animation (BRLAN), if present
- `banner/anim-loop.json` — Loop animation (BRLAN)
- `banner/textures/` — Decoded texture PNGs + textures.json manifest
- `banner/fonts/` — Font metadata + glyph sheet PNGs
- `icon/` — Same structure as banner (if icon is present)
- `audio.wav` — Channel audio (if present)
