# Wii Channel Renderer Bundle

Source: Wii Shop Channel (World) (v20) (Channel).wad
Title ID: HABA

This bundle contains parsed renderer assets for wiishowcase. It is not a pre-rendered
video or frame sequence; the runtime uploads textures and renders the layout live.
