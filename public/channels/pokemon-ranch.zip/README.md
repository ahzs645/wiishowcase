# Wii Channel Renderer Bundle

Source: My Pokemon Ranch (USA) (v256) (WiiWare).wad
Title ID: WBME

This bundle contains parsed renderer assets for wiishowcase. It is not a pre-rendered
video or frame sequence; the runtime uploads textures and renders the layout live.
